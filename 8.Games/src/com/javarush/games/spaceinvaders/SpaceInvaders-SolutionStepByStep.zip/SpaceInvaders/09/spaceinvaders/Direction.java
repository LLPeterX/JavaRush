package com.javarush.games.spaceinvaders;

public enum Direction {
    RIGHT,
    LEFT,
    UP,
    DOWN
}
