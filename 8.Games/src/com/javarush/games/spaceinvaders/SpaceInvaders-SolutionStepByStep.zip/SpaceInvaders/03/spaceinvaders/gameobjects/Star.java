package com.javarush.games.spaceinvaders.gameobjects;

public class Star extends GameObject {
    public Star(double x, double y) {
        super(x, y);
    }
}
