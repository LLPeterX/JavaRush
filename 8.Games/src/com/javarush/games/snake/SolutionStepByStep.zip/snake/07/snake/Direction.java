package com.javarush.games.snake;

public enum Direction {
    UP,
    RIGHT,
    DOWN,
    LEFT
}
