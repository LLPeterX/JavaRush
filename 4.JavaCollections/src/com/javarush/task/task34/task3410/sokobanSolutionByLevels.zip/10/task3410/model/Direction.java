package com.javarush.task.task34.task3410.model;

// Этот тип будет использоваться для описания направления движения объектов.
public enum Direction {
    LEFT,
    RIGHT,
    UP,
    DOWN
}
