package com.javarush.task.task34.task3410.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

// Загрузчик уровня из текстового файла
public class LevelLoader {
    private Path levels; // путь

    public LevelLoader(Path levels) {
        this.levels = levels;
    }

    public GameObjects getLevel(int level) {
        Set<Wall> walls = new HashSet<>();
        Set<Home> homes = new HashSet<>();
        Set<Box> boxes = new HashSet<>();
        Player player = null;

        level = (level == 60) ? 60 : level % 60;
        int fileLevel=0;
        try (BufferedReader reader = new BufferedReader(new FileReader(levels.toString()))) {
            String str;
            while((str = reader.readLine())!=null) {
                // читаем файл, пока не встретим строку Maze: - это индикатор уровня
                if(str.startsWith("Maze:")) {
                    fileLevel = getIntParam(str);
                    if(level == fileLevel) {
                        // пропустить до Length (хотя можно было бы и просто до пустой строки)
                        String tmp;
                        while ((tmp = reader.readLine()) != null) {
                            if (tmp.startsWith("Length:"))
                                break;
                        }
                        //reader.readLine(); // пропустить пустую строку
                        // читаем содержимое уровня, пока не будет "***
                        int row=0;
                        while((str = reader.readLine())!=null) {
                            //if(str.isEmpty() || str.startsWith("************")) break; // не помогает!
                            if(str.startsWith("************")) break;
                            int y = Model.FIELD_CELL_SIZE/2 + row*Model.FIELD_CELL_SIZE;
                            for(int i=0; i<str.length(); i++) { // по символам строки
                                int x = Model.FIELD_CELL_SIZE/2+i*Model.FIELD_CELL_SIZE;
                                char c = str.charAt(i);
                                switch (c) {
                                    case 'X':
                                        walls.add(new Wall(x,y));
                                        break;
                                    case '*': // ящик
                                        boxes.add(new Box(x,y));
                                        homes.add(new Home(x,y));
                                        break;
                                    case '&': // ящик в домике
                                        boxes.add(new Box(x,y));
                                        break;
                                    case '.':
                                        homes.add(new Home(x,y));
                                        break;
                                    case '@':
                                        player = new Player(x,y);
                                }
                            }
                            row++;
                        }
                    } // if level == fileLevel
                } // maze start
            } // main cycle
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new GameObjects(walls, boxes, homes, player);
    }

    // получить целочисленное значение из строки типа "Maze: 23"
    private int getIntParam(String s) {
        String[] tmp = s.split(" ");
        return  Integer.parseInt(tmp[1]);
    }

}
