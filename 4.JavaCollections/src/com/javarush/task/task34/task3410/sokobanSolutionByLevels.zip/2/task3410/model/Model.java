package com.javarush.task.task34.task3410.model;

public class Model {
    public static final int FIELD_CELL_SIZE = 20; // размер ячейки игрового поля

}
